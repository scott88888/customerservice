<?php
/**
 * @copyright ©2020 AI在线客服系统
 * Created by PhpStorm.
 * User: Andy - Wangjie
 * Date: 2020/6/17
 * Time: 17:15
 */


namespace app\admin\model;

use think\Model;

class Storage extends Model
{
    protected $table = 'wolive_storage';

}