<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2020/1/28
 * Time: 18:27
 */
namespace app\platform\model;

use think\Model;

class AdminLog extends Model
{


}