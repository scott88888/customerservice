<?php
/**
 * Date: 2021/2/17 0017
 * 技术支持微信: zrwx978
 */
return [
    // 去除已留信息提示
    'msgreminder' => 0  //1显示 0不显示
];